package br.senac.tads.dswa.exemplos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemplosJsApplicationTests {

	@Test
	void contextLoads() {
	}

}
